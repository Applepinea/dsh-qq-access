﻿# dsh-qq-access 0.2.1-local.1 — 本地修复与增强

上游版本：**0.2.0**。此包在 0.2.0 基础上打了下列补丁，均在 DSH **0.2.1-rc.3** 实测通过。

## 修复

### 1. 自动回复完全不工作（最严重）

三个叠加缺陷，任一都会导致「会话建了但零事件、`whenIdle()` 挂住」：

- `lib/runtime.mjs`：`agents.create()` 在未配置 `model` 段时不传 `agentOptions` → agent 没有模型，`followup()` 静默无输出。
  现在回落到宿主默认模型：`ctx.get('agentDefaultModel').currentSelection()`。
- `lib/runtime.mjs`：使用 `session.events`（数组）读取事件，但 rc.3 的 Session 只有 `seq` / `eventAt()` / `snapshotEvents()`。
  现在新增 `sessionEventList()` 兼容两种形状，`beforeSeq` 改用 `session.seq`。
- `lib/util.mjs`：`safeLog` 只写宿主 logger，Desktop 版看不到 → 上述异常被完全吞掉。
  现在同时追加到 `%USERPROFILE%\.dsh-qq-access\debug.log`（截断 4000 字符，不含正文/凭据）。

### 2. 每次异常退出后无法启动（锁不校验 pid）

`lib/store.mjs` 的 `acquireLock()` 只检查文件是否存在。DSH 被强杀后 `runtime.lock` 残留，插件永久报「数据目录已被使用」。

现在读取锁内 pid 并用 `process.kill(pid, 0)` 探活：进程已死则接管并重建锁；进程存活仍拒绝。三种情形均有测试。

### 3. QQ 空间留言无法发表

`lib/qzone.mjs` 的 `leaveMessage()` 假设编辑框是 `veditor1_Iframe` 子框架，但当前 Qzone 默认折叠编辑区，必须先点 `#btnWantPost`（「我要留言」）。

现在：先展开 → 等待 `veditor1_Iframe` 出现 → 保留 `textarea#maskEditor` 兜底分支。

### 4. 留言板读不到内容

- `#open(guestbook)` 找到框架后立即取文本，懒加载尚未完成 → 现在等待 1.5s，且单帧失败后重试一次。
- `itemCount()` 缓存了提交前的 frame 引用，提交后 iframe 重建即失效 → 现在每次重新解析。
- 提交后列表常需重新加载才刷新 → 增加 `page.reload()` 复核路径。

> 已知限制：`qq_qzone_leave_message` 实际能成功发表（多次实测留言板上榜），但确认逻辑仍可能返回
> `status: "uncertain"`。这是保守的假阴性；`ActionLedger` 按 `request_id` 去重，重试不会重复发送。
> 看到 `uncertain` 请到留言板人工核对，**不要换新 request_id 重发**。

### 5. 版本闸门

`engines.dsh` 由 `>=0.2.1-rc.4` 放宽为 `>=0.2.1-rc.3`。已用插件自带契约测试在 rc.3 上验证：
8 个工具定义的 JSON Schema、`createUserMessage`、`agents.create`/`followup`/`whenIdle`、`tools.guard` 全部满足。
因此不再需要 profile 级 `compatibility.json` 豁免。

## 新增：Web 管理面板

`lib/client.js`（客户端）+ `lib/ui.mjs`（宿主路由）。左侧栏新增「QQ 接入」入口，
另在「设置」下注册同一面板作为兜底。

功能：

1. 自动回复开关（私聊总开关、群聊 off / mention / all）
2. 回复范围（私聊 all / allowlist / disabled + 白名单；群消息三档；管理员 QQ）
3. NapCat 入口（托管模式、WebUI 端口、一键打开登录页）
4. 人格设定（persona 直接编辑）
5. 实时状态（在线徽标、账号、NapCat 版本与状态）、本地归档保留天数

接口（全部同源、回环 + Origin 双重校验）：

| 路由 | 方法 | 作用 |
|---|---|---|
| `/dsh-qq/api/state` | GET | 连接状态 + NapCat 状态 + 当前配置 |
| `/dsh-qq/api/config` | POST | 白名单合并 → `normalizeConfig` 校验 → 写盘 → 热更新 runtime |
| `/dsh-qq/api/napcat/open` | POST | 打开 NapCat 登录页 |

热更新范围：`reply` / `access` / `persona` / `ownerIds` / `retentionDays` /
`napcat.autoOpenLogin` / `autoInstall` / `maxRestarts`。
`napcat.mode` 与 `napcat.webuiPort` 变更需重载插件（界面会明确提示）。

## 安装

```powershell
dsh plugin --profile desktop add <本 tgz 完整路径>
```

或在插件管理器里选择本地 `.tgz`。安装后重启 DSH，并在左侧栏找到「QQ 接入」。

首次使用仍需生成配置（交互式）：

```powershell
node "<profile>\node_modules\dsh-qq-access\cli.mjs" setup
```

## 已知问题

- `qq_qzone_leave_message` 的成功确认偏保守（见上）。
- QQ 空间登录态为冻结的持久 cookie，`skey` 服务端通常数小时到一天失效，需要重跑 `qzone-login`。
- 面板 UI 文案为中文硬编码，未接入 Client locale 服务。
- 未包含上游 `tests/`（tgz 的 `files` 字段本就不含）。
